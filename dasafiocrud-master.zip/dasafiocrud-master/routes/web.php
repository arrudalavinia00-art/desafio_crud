<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;

Route::get('/', function () {
    return view('welcome');
});

// Listar todos os posts
Route::get('/posts', [PostController::class, 'index'])->name('posts.index');
// Exibir um post específico
Route::get('/posts/{id}', [PostController::class, 'show'])->name('posts.show');
// Formulário de criação de post
Route::get('/posts/create', [PostController::class, 'create'])->name('posts.create');
// Processar criação de post
Route::post('/posts', [PostController::class, 'store'])->name('posts.store');
// Formulário de edição de post
Route::get('/posts/{id}/edit', [PostController::class, 'edit'])->name('posts.edit');
// Processar atualização de post
Route::patch('/posts/{id}', [PostController::class, 'update'])->name('posts.update');
// Processar exclusão de post
Route::delete('/posts/{id}', [PostController::class, 'destroy'])->name('posts.destroy');
