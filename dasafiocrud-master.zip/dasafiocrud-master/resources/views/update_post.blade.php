@extends('layouts.app')
@section('content')
    <h1>Editar Post</h1>
    <form action="{{ route('posts.update', $post['id']) }}" method="POST">
        @csrf
        @method('PATCH')
        <div class="mb-3">
            <label for="titulo" class="form-label">Título</label>
            <input type="text" class="form-control" id="titulo" name="titulo" value="{{ $post['titulo'] }}" required>
        </div>
        <div class="mb-3">
            <label for="conteudo" class="form-label">Conteúdo</label>
            <textarea class="form-control" id="conteudo" name="conteudo" rows="4" required>{{ $post['conteudo'] }}</textarea>
        </div>
        <button type="submit" class="btn btn-primary">Atualizar</button>
        <a href="{{ route('posts.index') }}" class="btn btn-secondary">Cancelar</a>
    </form>
@endsection
