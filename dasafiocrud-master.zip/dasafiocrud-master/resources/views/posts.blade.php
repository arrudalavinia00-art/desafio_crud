@extends('layouts.app')
@section('content')
    <h1>Lista de Posts</h1>
    <a href="{{ route('posts.create') }}" class="btn btn-success mb-2">Criar Novo Post</a>
    <ul>
        @foreach($posts as $post)
            <li class="mb-2">
                <a href="{{ route('posts.show', $post['id']) }}">{{ $post['titulo'] }}</a>
                <a href="{{ route('posts.edit', $post['id']) }}" class="btn btn-sm btn-warning ms-2">Editar</a>
                <form action="{{ route('posts.destroy', $post['id']) }}" method="POST" style="display:inline">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-sm btn-danger">Excluir</button>
                </form>
            </li>
        @endforeach
    </ul>
@endsection
