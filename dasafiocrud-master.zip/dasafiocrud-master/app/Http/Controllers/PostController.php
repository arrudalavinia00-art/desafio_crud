<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostController extends Controller
{
    private function getPosts()
    {
        return [
            1 => ['id' => 1, 'titulo' => 'Primeiro Post', 'conteudo' => 'Conteúdo do primeiro post.'],
            2 => ['id' => 2, 'titulo' => 'Segundo Post', 'conteudo' => 'Conteúdo do segundo post.'],
        ];
    }

    public function index()
    {
        $posts = $this->getPosts();
        return view('posts', compact('posts'));
    }

    public function show($id)
    {
        $posts = $this->getPosts();
        $post = $posts[$id] ?? null;
        if (!$post) {
            abort(404);
        }
        return view('post_detalhe', compact('post'));
    }

    public function create()
    {
        return view('create_post');
    }

    public function store(Request $request)
    {
        return redirect()->route('posts.index');
    }

    public function edit($id)
    {
        $posts = $this->getPosts();
        $post = $posts[$id] ?? null;
        if (!$post) {
            abort(404);
        }
        return view('update_post', compact('post'));
    }

    public function update(Request $request, $id)
    {
        return redirect()->route('posts.index');
    }

    public function destroy($id)
    {
        return redirect()->route('posts.index');
    }
}
